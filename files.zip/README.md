# Preprocessing Teks Ulasan E-Commerce Berbahasa Indonesia

- **Nama** : HELIN MUTIARA
- **NIM**  : 24146022
- **Kelas**: ISI KELAS

## Deskripsi
Tugas preprocessing teks pada dataset
[ecommerce-product-reviews-sentiment](https://huggingface.co/datasets/dipawidia/ecommerce-product-reviews-sentiment)
(11.606 ulasan, label sentimen 0 = negatif, 1 = positif).

Tahapan: case folding, cleaning, tokenisasi, stopword removal, dan stemming (Sastrawi).

## Isi repositori
- `preprocessing_ulasan_ecommerce.ipynb` : notebook (informasi dataset, preprocessing, 10 contoh sebelum/sesudah, analisis)
- `Laporan_Preprocessing_Teks.pdf` : laporan (dibuat otomatis oleh notebook)

## Cara menjalankan
1. Buka notebook di Google Colab, isi `NAMA`, `NIM`, `KELAS`, dan `GITHUB_URL` pada sel pertama.
2. Jalankan semua sel (Runtime > Run all). Library (Sastrawi, datasets, reportlab) terpasang otomatis.
3. File `Laporan_Preprocessing_Teks.pdf` terunduh otomatis di akhir.
